# Ed. Democrata — versão HTML simples (sem npm, sem terminal)

Essa versão é um único site estático: `index.html` + `manifest.json` +
`sw.js` + os ícones. Dá pra subir direto pelo próprio site do GitHub,
igual você já fez no outro projeto.

## Novidades desta versão

- **Assembleias / Reuniões** — card na tela inicial com convocações de
  assembleias extraordinárias (o síndico publica pelo Painel).
- **Boletos** — o morador baixa o boleto do mês e filtra os anteriores por
  mês. O síndico envia o arquivo pelo Painel, escolhendo o apto.
- **Ocorrências** — o morador relata um problema (com fotos, se quiser) e
  recebe confirmação na hora; o síndico vê e marca como resolvida no Painel.
- Login de morador agora exige senha própria (cadastrada no primeiro
  acesso, junto com um e-mail) — apto sozinho não basta mais.
- Botão "← Voltar" em todas as telas, e o botão/gesto de voltar do celular
  agora navega dentro do app em vez de fechar.

## 1. Configurar o Firebase

### 1.1 Criar o projeto
1. Acesse https://console.firebase.google.com
2. Clique em **"Adicionar projeto"**
3. Nome: `condominio-democrata` (ou o que preferir)
4. Pode desativar o Google Analytics → **Criar projeto** → **Continuar**

### 1.2 Registrar o app Web (gera as chaves que vão para o `index.html`)
1. Na tela inicial do projeto, clique no ícone **`</>`** (Web)
2. Apelido: `condominio-democrata-web`
3. **Não** marque a opção de Firebase Hosting
4. **Registrar app** — vai aparecer um bloco assim:

```js
const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "condominio-democrata.firebaseapp.com",
  projectId: "condominio-democrata",
  storageBucket: "condominio-democrata.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef",
};
```
Copie esse bloco (ou anote os 6 valores) e clique em **"Ir para o console"**.

### 1.3 Ativar o banco de dados (Firestore)
1. Menu lateral → **Build → Firestore Database**
2. **Criar banco de dados**
3. Modo: **produção**
4. Localização: `southamerica-east1 (São Paulo)`
5. **Ativar**

### 1.4 Colar as regras de segurança
1. Ainda em Firestore Database, aba **Regras**
2. Apague o texto padrão e cole o conteúdo do arquivo `firestore.rules` (incluído neste pacote)
3. **Publicar**

### 1.5 Ativar o Storage (necessário para Boletos e fotos de Ocorrências)
1. Menu lateral → **Build → Storage**
2. **Vamos começar / Get started**
3. Modo: **produção** → mesma região do Firestore → **Concluído**
4. Aba **Regras** → apague o texto padrão e cole o conteúdo do arquivo
   `storage.rules` (incluído neste pacote) → **Publicar**

### 1.6 Colar as chaves no `index.html`
Abra o `index.html` (pode ser direto no editor do GitHub, clicando no lápis
do arquivo, depois de já ter subido os arquivos — passo 2 abaixo) e procure
este trecho perto do topo do `<script type="module">`:

```js
const firebaseConfig = {
  apiKey: "COLE_AQUI",
  authDomain: "COLE_AQUI",
  projectId: "COLE_AQUI",
  storageBucket: "COLE_AQUI",
  messagingSenderId: "COLE_AQUI",
  appId: "COLE_AQUI",
};
```
Substitua cada `"COLE_AQUI"` pelo valor correspondente do passo 1.2 e salve (commit).

### 1.7 Testar
Abra o link do GitHub Pages (ou dê duplo clique no `index.html` local) e
tente logar com apto `101` / senha `101`. Se a tela inicial abrir normal,
o Firestore está funcionando.

Se aparecer erro na tela, abra o Console do navegador (F12 → aba **Console**)
— o texto costuma começar com "Firebase: Error (...)" e indica exatamente o
que falta (regra de segurança, projeto errado, etc.).

## 2. Subir para o GitHub

1. Crie um repositório novo (ex.: `condominio-democrata`).
2. Clique em **"uploading an existing file"** (ou "Add file → Upload files")
   e arraste estes arquivos: `index.html`, `manifest.json`, `sw.js`,
   `icon-192.png`, `icon-512.png`, `icon-maskable-512.png`.
3. Commit.
## 3. Ativar o GitHub Pages

1. No repositório: **Settings → Pages**.
2. Em "Source", escolha **branch `main`, pasta `/ (root)`**.
3. Salve. Em alguns minutos aparece o link, algo como:
   `https://SEU-USUARIO.github.io/condominio-democrata/`

## 4. Instalar no Chrome

Abra esse link no Chrome:
- **Celular/Android**: menu (⋮) → **Instalar app**.
- **Computador**: ícone de instalação (⊕) que aparece na barra de endereço.

## Logins de teste

- Morador: apto = senha (ex.: `101` / `101`).
- Síndico: usuário `sindico`, senha `sindico123` (subsíndico: `subsindico` / `subsindico123`).

Troque essas senhas assim que possível — hoje elas ficam salvas em texto
simples no Firestore (sem Firebase Authentication ainda), então evite
reaproveitar senhas importantes.

## Se quiser editar depois

Todo o app está dentro de `index.html` — HTML, CSS e o JavaScript (com o
Firebase) estão no mesmo arquivo. Para mudar textos, cores ou os apartamentos
cadastrados (`FLOORS` / `UNITS` perto do topo do script), edite direto por lá,
pelo próprio editor do GitHub, e salve — não precisa de build nem de instalar
nada no computador.
